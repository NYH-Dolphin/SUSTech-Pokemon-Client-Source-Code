﻿/**
 * Created by SharpDevelop.
 * User: Neolows
 * Date: 2021/9/13
 * Time: 17:54
 */
using System;

namespace SUSCTmonster.model.map
{
	/// <summary>
	/// Description of Map.
	/// </summary>
	public class Map
	{
		public Map()
		{
		}
	}
}
