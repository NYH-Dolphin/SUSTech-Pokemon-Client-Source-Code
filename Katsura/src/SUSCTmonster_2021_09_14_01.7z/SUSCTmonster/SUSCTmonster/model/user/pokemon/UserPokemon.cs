﻿/**
 * Created by SharpDevelop.
 * User: Neolows
 * Date: 2021/9/13
 * Time: 17:57
 */
using System;

namespace SUSCTmonster.model.user.pokemon{
	public class UserPokemon : monster.Pokemon{
		protected bool own = false;
		
		//return false if user already has it and true otherwise
		public bool getPokemon(){
			if(this.own = true)return false;
			else{
				own = true;
				return true;
			}
		}
	}
}
