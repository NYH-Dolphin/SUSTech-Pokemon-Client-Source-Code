﻿/**
 * Created by SharpDevelop.
 * User: Neolows
 * Date: 2021/9/13
 * Time: 17:48
 */
using System;
using System.Collections.Generic;

namespace SUSCTmonster.model.user{
	public class User{
		protected readonly long ID;
		protected String name;
		protected String password;
		
		protected bag.Bag bag;
		protected HastSet<pokemon.UserPokemon> userPokemon;
		
		
		//sever should check the name is unique and dicide an ID
		public User(String name, String password){
			this.name = name;
			this.password = password;
			
			//TODO
			this.ID = 1L;
			this.userPokemon = new HashSet();
			this.userPokemon.add(new pokemon.UserPokemon.PokemonBuilder().setAtk(new monster.effection.Attack(50.0,"扇一巴掌")).setHP(500.0).setName("电耗子"));
		}
	}
}
