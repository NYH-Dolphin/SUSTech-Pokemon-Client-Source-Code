﻿/**
 * Created by SharpDevelop.
 * User: Neolows
 * Date: 2021/9/11
 * Time: 11:26
 */
using System;

namespace SUSCTmonster.model.monster.effection{
	public class Attack : Effection{
		//TODO more than just baseAtk
		private readonly double baseAtk;
		private readonly String name;
		
		public Attack(double baseAtk,String name){this.baseAtk = baseAtk;this.name = name;}
		
		public override void addHP(monster.Monster monster){
			monster.addHP(this.baseAtk * -1);
		}
		
		public override string ToString()
		{
			return string.Format("[Attack BaseAtk={0}, Name={1}]", baseAtk, name);
		}

	}
}
