﻿/**
 * Created by SharpDevelop.
 * User: Neolows
 * Date: 2021/9/11
 * Time: 9:56
 */
using System;

namespace SUSCTmonster.model.monster{
	public class Pokemon : Monster{
		protected Pokemon(){}
		protected Pokemon(double? hP_,String name_,effection.Attack atk){
			this.hP = hP_;this.name = name_;this.atk = atk;
		}
		
		public override string ToString(){
			return string.Format("[Pokemon HP={0}, Name={1}, Atk={2}]", hP, name, atk);
		}

		public class PokemonBuilder{
			//TODO rename
			private Pokemon bPokemon = null;
			private double? bHP = null;
			private String bName = null;
			private effection.Attack atk = null;
		
			public PokemonBuilder(){
				this.bPokemon = new Pokemon();
			}
			
			//shoude be name as hp
			public PokemonBuilder setHP(double? hP_){
				if(this.bHP != null){throw(new AlreadySetedException("HP is already set!"));return this;}
				this.bHP = hP_ ;return this;
			}
			
			public PokemonBuilder setName(String name_){
				if(this.bName != null){throw(new AlreadySetedException("Name is already set!"));return this;}
				this.bName = name_;return this;
			}
			
			public PokemonBuilder setAtk(effection.Attack atk){
				if(this.atk != null){throw(new AlreadySetedException("ATK is already set!"));return this;}
				this.atk = atk;return this;
			}
			
			public Pokemon build(){
				if(this.bHP == null){throw(new BuilderLackEssentialStepException("HP is not set yet!"));return null;}
				if(this.bName == null){throw(new BuilderLackEssentialStepException("Name is not set yet!"));return null;}
				return new Pokemon(this.bHP,this.bName,this.atk);
			}
		}
	}
	
}
