﻿/**
 * Created by SharpDevelop.
 * User: Neolows
 * Date: 2021/9/11
 * Time: 11:10
 */
using System;

namespace SUSCTmonster.model.monster
{
	public class AlreadySetedException : Exception{
   		public AlreadySetedException(string message): base(message){}
	}
}
