﻿/**
 * Created by SharpDevelop.
 * User: Neolows
 * Date: 2021/9/11
 * Time: 11:08
 */
using System;

namespace SUSCTmonster.model.monster
{

	public class BuilderLackEssentialStepException: Exception{
   		public BuilderLackEssentialStepException(string message): base(message){}
	}
}
