﻿/**
 * Created by SharpDevelop.
 * User: Neolows
 * Date: 2021/9/11
 * Time: 9:54
 */
using System;

namespace SUSCTmonster.model.monster{
	public abstract class Monster{
		protected double? hP;
		protected String name;
		protected effection.Attack atk;
		
		public void hit(Monster m,effection.Effection atk){
			m.beenHit(atk);
		}
		
		public void beenHit(effection.Effection atk){
			atk.effectMonster(this);
		}
		
		public void addHP(double d){
			this.hP += d;
		}
		
		public effection.Attack getAtk(){
			return atk;
		}
	}
}
