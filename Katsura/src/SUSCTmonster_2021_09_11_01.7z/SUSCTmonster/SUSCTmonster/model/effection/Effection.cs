﻿/**
 * Created by SharpDevelop.
 * User: Neolows
 * Date: 2021/9/11
 * Time: 11:21
 */
using System;

namespace SUSCTmonster.model.effection
{
	public abstract class Effection{
		public void effectMonster(monster.Monster monster){
			addHP(monster);
		}
		
		public abstract void addHP(monster.Monster monster);
	}
}
