﻿/**
 * Created by SharpDevelop.
 * User: Neolows
 * Date: 2021/9/11
 * Time: 9:58
 */
using System;

namespace SUSCTmonster.model.skill.attack{
	public class Attack{
		private double baseDamage;
		
		public Attack(double baseDamage){
			this.baseDamage = baseDamage;
		}
		
		public void hit(monster.Monster monster){
			
		}
	}
}
