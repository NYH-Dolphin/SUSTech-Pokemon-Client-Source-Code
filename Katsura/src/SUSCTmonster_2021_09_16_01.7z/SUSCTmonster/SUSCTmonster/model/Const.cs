﻿/**
 * Created by SharpDevelop.
 * User: Neolows
 * Date: 2021/9/16
 * Time: 16:27
 */
using System;

namespace SUSCTmonster.model
{
	public static class Const{
		public const double eqs = 0.000001;
	}
}
