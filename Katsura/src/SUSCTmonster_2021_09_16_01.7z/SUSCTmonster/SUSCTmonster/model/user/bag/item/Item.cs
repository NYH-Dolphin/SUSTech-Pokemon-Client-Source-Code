﻿/**
 * Created by SharpDevelop.
 * User: Neolows
 * Date: 2021/9/13
 * Time: 18:12
 */
using System;

namespace SUSCTmonster.model.user.bag.item
{
	public abstract class Item{
		public double weight;
		
		//should not more than 1,000,000
		public int count;

	}
}
