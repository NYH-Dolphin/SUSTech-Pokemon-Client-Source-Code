﻿/**
 * Created by SharpDevelop.
 * User: Neolows
 * Date: 2021/9/13
 * Time: 17:56
 */
using System;

namespace SUSCTmonster.model.user.bag.item
{
	public class GoldCoin : Item
	{
		public GoldCoin()
		{
		}
	}
}
