﻿/**
 * Created by SharpDevelop.
 * User: Neolows
 * Date: 2021/9/13
 * Time: 18:16
 */
using System;

namespace SUSCTmonster.model.user
{
	public class UserTest
	{
		public UserTest()
		{
		}
	}
}
