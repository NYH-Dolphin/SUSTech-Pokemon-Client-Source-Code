﻿/**
 * Created by SharpDevelop.
 * User: Neolows
 * Date: 2021/9/13
 * Time: 18:03
 */
using System;

namespace SUSCTmonster.model.scene.map.events
{
	/// <summary>
	/// Description of FindTreaser.
	/// </summary>
	public class FindTreaser
	{
		public FindTreaser()
		{
		}
	}
}
