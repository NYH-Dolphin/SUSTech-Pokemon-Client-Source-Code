﻿/**
 * Created by SharpDevelop.
 * User: Neolows
 * Date: 2021/9/13
 * Time: 17:55
 */
using System;

namespace SUSCTmonster.model.map.block{
	public class Block{
		public Block()
		{
		}
	}
}
