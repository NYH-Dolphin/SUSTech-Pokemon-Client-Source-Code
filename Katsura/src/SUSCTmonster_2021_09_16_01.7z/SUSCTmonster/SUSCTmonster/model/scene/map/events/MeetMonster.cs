﻿/**
 * Created by SharpDevelop.
 * User: Neolows
 * Date: 2021/9/13
 * Time: 17:54
 */
using System;

namespace SUSCTmonster.model.map.events
{
	/// <summary>
	/// Description of MeetMonster.
	/// </summary>
	public class MeetMonster
	{
		public MeetMonster()
		{
		}
	}
}
