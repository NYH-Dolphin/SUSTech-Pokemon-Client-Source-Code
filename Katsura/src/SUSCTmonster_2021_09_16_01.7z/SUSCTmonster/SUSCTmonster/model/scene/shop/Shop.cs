﻿/**
 * Created by SharpDevelop.
 * User: Neolows
 * Date: 2021/9/13
 * Time: 17:58
 */
using System;

namespace SUSCTmonster.model.Scene.shop
{
	/// <summary>
	/// Description of Shop.
	/// </summary>
	public class Shop
	{
		public Shop()
		{
		}
	}
}
