﻿/**
 * Created by SharpDevelop.
 * User: Neolows
 * Date: 2021/9/11
 * Time: 10:10
 */
using System;

namespace SUSCTmonster.model.monster{
	public class PokemonTest{
		public static void testPokemonBuilder(){
			Pokemon p = new Pokemon.PokemonBuilder()
				.setHP(500.0).setName("电耗子").setAtk(new effection.Attack(500.0,"来一拳")).build();
			Console.WriteLine(p.ToString());
		}
		
		public static void testNoNameException(){
			Pokemon p = new Pokemon.PokemonBuilder()
				.setHP(500.0).build();
			Console.WriteLine(p.ToString());
		}
		
		public static void testAlreadySetedException(){
			Pokemon p = new Pokemon.PokemonBuilder()
				.setHP(500.0).setName("电耗子").setName("超级电耗子").build();
			Console.WriteLine(p.ToString());
		}
		
		public static void testAtk(){
			Pokemon p2 = new Pokemon.PokemonBuilder()
				.setHP(500.0).setName("电耗子").setAtk(new effection.Attack(200.0,"扇一巴掌")).build();
			
			Pokemon p1 = new Pokemon.PokemonBuilder()
				.setHP(1500.0).setName("超级电耗子").setAtk(new effection.Attack(300.0,"给脸上来一拳")).build();
			
			Console.WriteLine(p1.ToString());
			Console.WriteLine(p2.ToString() + "\n");
			
			Console.WriteLine("{0} 对着 {1} 使用了 {2} \n",p1,p2,p2.getAtk());
			p1.hit(p2,p1.getAtk());
			
			Console.WriteLine(p1.ToString());
			Console.WriteLine(p2.ToString());
		}
		
		public static void Main(string[] args){
			//testPokemonBuilder();
			//testNoNameException();
			//testAlreadySetedException();
			testAtk();
			
			Console.Read();
		}
	}
}
