﻿/**
 * Created by SharpDevelop.
 * User: Neolows
 * Date: 2021/9/11
 * Time: 9:54
 */
using System;

namespace SUSCTmonster.model.monster{
	
	//Should contain esstial proproty of a monster and in what way effection can be effect to Monster
	//Should check each method is valid, such as damage upper bounds
	public abstract class Monster{
		protected double? hP;
		protected String name;
		
		//TODO should be array
		protected effection.Attack atk;
		
		
		//TODO one hit maybe has a lot effection on sequnce
		public void hit(Monster m,effection.Effection atk){
			m.beenHit(atk);
		}
		
		public void beenHit(effection.Effection atk){
			atk.effectMonster(this);
		}
		
		public void addHP(double d){
			this.hP += d;
		}
		
		//Proproty change should be protected, effection need be under monster
		public effection.Attack getAtk(){
			return atk;
		}
	}
}
