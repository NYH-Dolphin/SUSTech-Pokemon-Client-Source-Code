﻿/**
 * Created by SharpDevelop.
 * User: Neolows
 * Date: 2021/9/16
 * Time: 15:57
 */
using System;
using NUnit.Framework;

namespace SUSCTmonster.model.monster
{
	[TestFixture]
	public class PokemonUnitTest
	{
		[Test]
		public void testToString(){
			Pokemon p = new Pokemon.PokemonBuilder()
				.setHP(500.0).setName("电耗子").setAtk(new effection.Attack(500.0,"来一拳")).build();
			Assert.AreEqual(p.ToString() , "[Pokemon HP=500, Name=电耗子, Atk=[Attack BaseAtk=500, Name=来一拳]]");
		}
		
		[Test]
		public void testNoNameException(){
			try{
				Pokemon p = new Pokemon.PokemonBuilder().setHP(500.0).build();
			}catch(BuilderLackEssentialStepException e){
				Assert.Pass();
			};
			Assert.Fail();
		}
		
		[Test]
		public void testAlreadySetedException(){
			try{
				Pokemon p = new Pokemon.PokemonBuilder().setHP(500.0).setName("电耗子").setName("超级电耗子").build();
			}catch(AlreadySetedException e){
				Assert.Pass();
			};
			Assert.Fail();
		}
		
		[Test]
		public void testAtk(){
			Pokemon p2 = new Pokemon.PokemonBuilder()
				.setHP(500.0).setName("电耗子").setAtk(new effection.Attack(200.0,"扇一巴掌")).build();
			
			Pokemon p1 = new Pokemon.PokemonBuilder()
				.setHP(1500.0).setName("超级电耗子").setAtk(new effection.Attack(300.0,"给脸上来一拳")).build();

			p1.hit(p2,p1.getAtk());
			
			Pokemon p3 = new Pokemon.PokemonBuilder()
				.setHP(200.0).setName("电耗子").setAtk(new effection.Attack(200.0,"扇一巴掌")).build();
		
			Assert.AreEqual((Double)p2.getHP(),(Double)200.0,(Double)Const.eqs);
		}
	}
}
